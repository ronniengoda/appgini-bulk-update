<?php 
/**
 * include important things first
 */
define("PREPEND_PATH", "../../");
$hooks_dir = dirname(__FILE__);
include("../../defaultLang.php");
include("../../language.php");
include("../../lib.php");
include_once("../../header.php");
include '../../config.php';

#####MAKE CONNECTION TO DB##################
$con=mysqli_connect($dbServer,$dbUsername,$dbPassword,$dbDatabase);
if (mysqli_connect_errno()) {
	# code...
	echo "could not connect to mysql database because ".mysqli_connect_error();
}
##############DB CONNECTION#################

########## GET PAGE URL#####################
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
	$url = "https://";   
else  
	$url = "http://";   
    // Append the host(domain name, ip) to the URL.   
$url.= $_SERVER['HTTP_HOST'];   

    // Append the requested resource location to the URL   
$url.= $_SERVER['REQUEST_URI'];    
 ###########################################
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-heading" id="pheading"><strong>Bulk Update Plugin</strong></div>
				<div class="panel-body">
					<div class="form-group">
						<form method="POST" action="<?php echo $url;?>">
							<div class="form-group" id="gettable">
								<label for="tablename">Select Table:</label>
								<select class="form-control" id="tablename" name="tablename">
									<?php
									//Get All Tables Of Current Dtabase
									$Tnames=sql("SELECT `TABLE_NAME` AS tname
										FROM `INFORMATION_SCHEMA`.`TABLES` 
										WHERE `TABLE_SCHEMA`='$dbDatabase'",$eo);
									while ($trow=db_fetch_assoc($Tnames)) {
										# code...
										echo '<option value="'.$trow['tname'].'">'.$trow['tname'].'</option>';
									}
									?>
								</select><br>
								<button type="submit" class="btn btn-success btn-block" id="next"><strong>Next</strong></button>
							</div>
						</form>
					</div>

					<?php 
					if (isset($_POST['tablename'])) {
						# code...
						echo '<script>document.getElementById("next").disabled = true;</script>';
						$_SESSION["tablename"]=$_POST['tablename'];
					} 
					if (isset($_POST['update'])) {
						# code...
						$column=$_POST['colname'];
						$newvalue=makeSafe($_POST['newvalue']);
						$condition=$_POST['condition'];
						$table=$_SESSION['tablename'];

						sql("UPDATE $table SET $column='$newvalue' $condition",$eo);
						echo '<script>alert("Congratulations!! Records Updated Successfully");</script>';
						echo '<script>document.getElementById("next").disabled =false;</script>';
						unset($_SESSION["tablename"]);
					}
					?>

					<form method="POST" action="<?php echo $url;?>">
						<div class="form-group" id="getcolumn">
							<label for="colname">Select Field:</label>
							<select class="form-control" id="colname" name="colname">
								<?php 
								//Get All Column Names Of The Selected Table
								$table=$_SESSION['tablename'];
								$FNQ=sql("SELECT `COLUMN_NAME` AS tcols
									FROM `INFORMATION_SCHEMA`.`COLUMNS` 
									WHERE `TABLE_SCHEMA`='$dbDatabase' 
									AND `TABLE_NAME`='$table'",$eo);
								while ($trow=db_fetch_assoc($FNQ)) {
										# code...
									echo '<option value="'.$trow['tcols'].'">'.$trow['tcols'].'</option>';
								}
								?>
							</select>
							<label for="newvalue">Enter New Value:</label>
							<input type="text" class="form-control" id="newvalue" name="newvalue" required="YES" placeholder="Enter Value You Want To Update">
							<label for="newvalue">Enter Condition: (Must be an sql compliant query beginning with WHERE): </label>
							<input type="text" class="form-control" id="condition" name="condition" placeholder="Enter Condition eg WHERE status='Active'">
							<br>
							<button type="submit" class="btn btn-success btn-block" id="update" name="update"><strong>Update</strong></button>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>